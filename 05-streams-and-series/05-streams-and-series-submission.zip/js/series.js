import { sempty, snode, from } from "../include/stream.js";
export function addSeries(s, t) {
    if (s.isEmpty())
        return t;
    else if (t.isEmpty())
        return s;
    return snode(s.head() + t.head(), () => addSeries(s.tail(), t.tail()));
}
export function prodSeries(s, t) {
    if (s.isEmpty() || t.isEmpty())
        return sempty();
    return addSeries(t.map(x => x * s.head()), snode(0, () => prodSeries(s.tail(), t)));
}
function prodOneOne(s, t) {
    if (s.isEmpty() || t.isEmpty())
        return sempty();
    return snode(s.head() * t.head(), () => prodOneOne(s.tail(), t.tail()));
}
export function derivSeries(s) {
    return prodOneOne(s, from(0)).tail();
}
function maskN(n) {
    return n < 0 ? sempty() : snode(1, () => maskN(n - 1));
}
export function coeff(s, n) {
    let firstN = prodOneOne(s, maskN(n));
    const arr = [];
    while (!firstN.isEmpty()) {
        arr.push(firstN.head());
        firstN = firstN.tail();
    }
    return arr;
}
export function evalSeries(s, n) {
    return x => coeff(s, n).reduce((acc, i) => {
        return [acc[0] + i * Math.pow(x, acc[1]), acc[1] + 1];
    }, [0, 0])[0];
}
export function applySeries(f, v) {
    return snode(v, () => applySeries(f, f(v)));
}
function invertFactorial() {
    let count = 0;
    return x => {
        count += 1;
        return x / count;
    };
}
export function expSeries() {
    return applySeries(invertFactorial(), 1);
}
function dotProduct(s, t) {
    if (s.length === 0 || t.length === 0)
        return 0;
    return s[0] * t[0] + dotProduct(s.slice(1), t.slice(1));
}
function recurCount(len_init, init, coef) {
    let k = 0;
    const stream = [init[0]];
    function something() {
        k += 1;
        if (k < len_init) {
            stream.push(init[k]);
            return snode(init[k], () => something());
        }
        else {
            const res = snode(dotProduct(stream, coef), () => something());
            stream.push(dotProduct(stream, coef));
            stream.shift();
            return res;
        }
    }
    return something;
}
export function recurSeries(coef, init) {
    return snode(init[0], () => recurCount(init.length, init, coef)());
}
//# sourceMappingURL=series.js.map