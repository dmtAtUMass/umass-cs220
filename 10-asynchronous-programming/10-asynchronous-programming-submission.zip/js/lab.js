import fetch from "../include/fetch";
export function getObjsWithName(urls) {
    return Promise.allSettled(urls.map((url) => fetch(url).then(res => res.json()))).then(firstarr => firstarr
        .filter((res) => res.status === "fulfilled")
        .map(r => r["value"])
        .map(objarr => objarr.filter(obj => "name" in obj))
        .flat());
}
// Lets try using our function!
const urls = [
    "https://api.github.com/users/umass-compsci-220/repos",
    "https://api.github.com/users/umass-cs-230/repos",
];
getObjsWithName(urls)
    .then(obs => obs.map(obj => obj["name"]))
    .then(console.log)
    .catch(console.log);
/**
 * Exercise 2
 */
// composeFunctionsAsync
export function composeFunctionsAsync(asyncFuncArr) {
    return (a) => {
        return asyncFuncArr.reduce((acc, f) => acc.then(f), Promise.resolve(a));
    };
}
const getjson = composeFunctionsAsync([
    fetch,
    (res) => (res.ok ? res.json() : Promise.reject(`${res.status} : ${res.statusText}`)),
]);
/* test async function composition */
getjson("https://api.github.com/users/umass-cs-230/repos")
    .then(res => res[0]["owner"])
    .then(console.log)
    .catch(console.log);
//# sourceMappingURL=lab.js.map