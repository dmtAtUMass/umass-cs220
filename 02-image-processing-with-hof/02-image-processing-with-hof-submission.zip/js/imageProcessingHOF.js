export function imageMapCoord(img, func) {
    const newImage = img.copy();
    for (let i = 0; i < img.width; i++) {
        for (let j = 0; j < img.height; j++) {
            newImage.setPixel(i, j, func(img, i, j));
        }
    }
    return newImage;
}
export function imageMapIf(img, cond, func) {
    return imageMapCoord(img, (image, x, y) => (cond(image, x, y) ? func(image.getPixel(x, y)) : image.getPixel(x, y)));
}
export function mapWindow(img, xInterval, // Assumed to be a two element array containing [x_min, x_max]
yInterval, // Assumed to be a two element array containing [y_min, y_max]
func) {
    // TODO
    return imageMapIf(img, (img, x, y) => xInterval[0] <= x && x <= xInterval[1] && yInterval[0] <= y && y <= yInterval[1], func);
}
export function isGrayish(p) {
    return Math.abs(Math.max(...p) - Math.min(...p)) <= 85;
}
export function mean(p) {
    return Math.floor(p.reduce((a, b) => a + b) / 3);
}
export function getNeighbors(img, x, y) {
    const neighbor = [];
    for (let i = x - 1; i <= x + 1; i++) {
        for (let j = y - 1; j <= y + 1; j++) {
            if (i >= 0 && i < img.width && j >= 0 && j < img.height) {
                neighbor.push(img.getPixel(i, j));
            }
        }
    }
    return neighbor;
}
export function makeGrayish(img) {
    return imageMapIf(img, (img, x, y) => !isGrayish(img.getPixel(x, y)), p => [mean(p), mean(p), mean(p)]);
}
export function pixelBlur(img, x, y) {
    // TODO
    const neighbor = getNeighbors(img, x, y);
    return neighbor.reduce((a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]]).map(e => Math.floor(e / neighbor.length));
}
export function imageBlur(img) {
    // TODO
    return imageMapCoord(img, (img, x, y) => pixelBlur(img, x, y));
}
//# sourceMappingURL=imageProcessingHOF.js.map