// import { escape } from "querystring";
import { Observable } from "../include/observable.js";
// Extra Credit Functions
export function classifyObservables(obsArr) {
    // TODO: Implement this function
    const string = new Observable();
    const number = new Observable();
    const boolean = new Observable();
    obsArr.forEach(obs => {
        obs.subscribe(val => {
            if (typeof val === "string") {
                string.update(val);
            }
            else if (typeof val === "number") {
                number.update(val);
            }
            else {
                boolean.update(val);
            }
        });
    });
    return { string, number, boolean };
}
export function obsStrCond(funcArr, f, o) {
    const result = new Observable();
    const compositeFunc = funcArr.reduce((acc, f1) => x => f1(acc(x)), x => x);
    o.subscribe(data => {
        if (f(compositeFunc(data)))
            result.update(compositeFunc(data));
        else
            result.update(data);
    });
    return result;
}
export function statefulObserver(o) {
    // TODO: Implement this function
    const result = new Observable();
    let prev = Infinity;
    o.subscribe(data => {
        if (prev !== 0 && data % prev === 0)
            result.update(data);
        prev = data;
    });
    return result;
}
// Optional Additional Practice
export function mergeMax(o1, o2) {
    const result = new Observable();
    let max = -Infinity;
    o1.subscribe(data => {
        if (data >= max)
            result.update({ obs: 1, v: data });
        max = Math.max(max, data);
    });
    o2.subscribe(data => {
        if (data >= max)
            result.update({ obs: 2, v: data });
        max = Math.max(max, data);
    });
    return result;
}
export function merge(o1, o2) {
    const result = new Observable();
    o1.subscribe(data => result.update(data));
    o2.subscribe(data => result.update(data));
    return result;
}
export class GreaterAvgObservable extends Observable {
    constructor() {
        super();
    }
    greaterAvg() {
        const result = new Observable();
        let prev1 = -Infinity;
        let prev2 = -Infinity;
        this.subscribe(data => {
            const conditions = [
                prev2 === -Infinity,
                prev1 === -Infinity && data >= 1.5 * prev1,
                data >= (1.5 * (prev1 + prev2)) / 2,
            ];
            if (conditions.some(e => e))
                result.update(data);
            prev1 = prev2;
            prev2 = data;
        });
        return result;
    }
}
export class SignChangeObservable extends Observable {
    constructor() {
        super();
    }
    signChange() {
        // TODO: Implement this method
        let prev = 0;
        const result = new Observable();
        this.subscribe(data => {
            if (data !== 0 && data * prev <= 0)
                result.update(data);
            prev = data;
        });
        return result;
    }
}
/**
 * This function shows how the class you created above could be used.
 * @param numArr Array of numbers
 * @param f Observer function
 */
export function usingSignChange(numArr, f) {
    const o = new SignChangeObservable();
    const o1 = o.signChange();
    o1.subscribe(data => f(data));
    numArr.forEach(e => o1.update(e));
}
//# sourceMappingURL=observables.js.map