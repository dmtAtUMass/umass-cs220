import { node, empty, reverseList } from "../include/lists.js";
export function everyNList(lst, n) {
    // TODO: Implement this function
    return reverseList(everyNRev(lst, n));
}
export function everyNRev(lst, n) {
    // TO DO: Implement this function
    return lst.reduce((acc, e) => {
        return acc[1] % n === 0 ? [node(e, acc[0]), acc[1] + 1] : [acc[0], acc[1] + 1];
    }, [empty(), 1])[0];
}
export function everyNCond(lst, n, cond) {
    return everyNList(lst.filter(e => cond(e)), n);
}
function conditionalProducts(lst, cond) {
    return reverseList(lst.reduce((acc, e) => {
        return cond(e) ? [node(e * acc[1], acc[0]), e * acc[1]] : [acc[0], 1];
    }, [empty(), 1])[0]);
}
export function nonNegativeProducts(lst) {
    // TODO: Implement this function
    return conditionalProducts(lst, (e) => e >= 0);
}
export function negativeProducts(lst) {
    // TODO: Implement this function
    return conditionalProducts(lst, (e) => e < 0);
}
export function squashList(lst) {
    // TODO: Implement this function
    return reverseList(lst.reduce((acc, e) => {
        return typeof e === "number"
            ? node(e, acc)
            : node(e.reduce((acc, e) => acc + e, 0), acc);
    }, empty()));
}
export function composeList(lst) {
    return lst.reduce((acc, e) => {
        return x => e(acc(x));
    }, e => e);
}
export function composeFunctions(funcArr) {
    // TODO: Implement this function
    return (x) => {
        return funcArr.reduce((acc, e) => {
            return (y) => e(acc(y), x);
        }, (x) => x);
    };
}
//# sourceMappingURL=lists.js.map